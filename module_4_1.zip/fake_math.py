def divide(first, second):
    if first != 0 and second != 0:
        total = first / second
        return total
    else:
        total = 'Ошибка'
        return total