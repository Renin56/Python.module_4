from math import inf

def divide(first, second):
    if first != 0 and second != 0:
        total = first / second
        return total
    elif second == 0:
        return inf
    else:
        total = ''
        return total